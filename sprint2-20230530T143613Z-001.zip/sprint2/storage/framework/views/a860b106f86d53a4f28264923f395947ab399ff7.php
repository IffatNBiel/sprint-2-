<?php $__env->startSection("content"); ?>
    <main class="flex-grow">
        <table class="w-full">
            <thead>
            <tr class="bg-gray-100 border-2 border-gray-100">
                <th class="px-8 py-2">No.</th>
                <th class="px-8 py-2">Tanggal</th>
                <th class="px-8 py-2">Jenis Transaksi</th>
                <th class="px-8 py-2">Pembayaran</th>
                <th class="px-8 py-2">Nama Pegawai</th>
                <th class="px-8 py-2">Invoice</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center border-2 border-gray-100"><?php echo e($no+1); ?></td>
                    <td class="text-center border-2 border-gray-100"><?php echo e($transaksi->tanggal); ?></td>
                    <td class="text-center border-2 border-gray-100"><?php echo e($transaksi->kategori_transaksi); ?></td>
                    <td class="text-center border-2 border-gray-100"><?php echo e($transaksi->total); ?></td>
                    <td class="text-center border-2 border-gray-100"><?php echo e($transaksi->user->name); ?></td>
                    <td class="text-center border-2 border-gray-100">
                        <?php echo $__env->make("pages.transaksi.detail", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <button type="button" data-modal-target="detailTransaksi-<?php echo e($no+1); ?>" data-modal-toggle="detailTransaksi-<?php echo e($no+1); ?>"
                                class="material-icons">file_open
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minerva/PhpstormProjects/ppl_griees/resources/views/pages/transaksi/index.blade.php ENDPATH**/ ?>
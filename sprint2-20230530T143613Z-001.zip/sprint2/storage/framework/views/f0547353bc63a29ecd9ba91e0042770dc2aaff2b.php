<?php $__env->startSection("content"); ?>
    <main class="flex-grow">
        <div class="p-4 flex flex-col items-center">
            <table class="w-full">
                <thead>
                <tr class="bg-gray-100">
                    <th class="px-8 py-2">No.</th>
                    <th class="px-8 py-2">Tanggal</th>
                    <th class="px-8 py-2 w-1/3">Jenis Pengeluaran</th>
                    <th class="px-8 py-2 w-1/3">Jumlah Pengeluaran</th>
                    <th class="px-8 py-2">Keterangan</th>
                    <th class="px-8 py-2">Bukti Pengeluaran</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $keluars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$keluar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i+1); ?></td>
                        <td><?php echo e($keluar->created_at); ?></td>
                        <td><?php echo e($keluar->jenis_pengeluaran); ?></td>
                        <td><?php echo e($keluar->jumlah_pengeluaran); ?></td>
                        <td><?php echo e($keluar->keterangan); ?></td>
                        <td><button>Bukti</button></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <a href="/keuangan/keluar/tambah" class="mt-4 w-1/3 text-center bg-slate-500 py-2 rounded-xl text-white">Tambah Data</a>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minerva/PhpstormProjects/ppl_griees/resources/views/pages/keuangan/index.blade.php ENDPATH**/ ?>

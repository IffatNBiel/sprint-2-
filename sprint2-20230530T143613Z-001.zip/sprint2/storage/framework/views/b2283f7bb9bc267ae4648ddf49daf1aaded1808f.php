<?php $__env->startSection("content"); ?>
    <main class="flex-grow bg-slate-200 h-screen">
        <div class="p-4 flex flex-col items-center gap-4">
            <form>
                <select onchange="submit()" name="created_at" id="created_at">
                    <?php $__currentLoopData = $times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($time->tanggal); ?>" <?php if($time->tanggal === request()->input("created_at")): ?> selected <?php endif; ?>>Tanggal: <?php echo e($time->tanggal); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>
            <div class="flex gap-4">
                <div class="flex flex-col items-center bg-slate-300 p-4 rounded-xl">
                    <h1 class="font-bold text-2xl">Pembelian</h1>
                    <div class="h-1 w-full bg-black"></div>
                    <h2 class="font-medium text-lg">Jumlah Transaksi</h2>
                    <h3><?php echo e($res["jumlahPembelian"]); ?></h3>
                    <h2 class="font-medium text-lg">Jumlah Produk Terjual</h2>
                    <h3><?php echo e($res["jumlahProdukPembelian"]); ?></h3>
                    <h2 class="font-medium text-lg">Jumlah Omzet</h2>
                    <h3>Rp. <?php echo e($res["totalPembelian"]); ?></h3>
                </div>
                <div class="flex flex-col items-center bg-slate-300 p-4 rounded-xl">
                    <h1 class="font-bold text-2xl">Pemesanan</h1>
                    <div class="h-1 w-full bg-black"></div>
                    <h2 class="font-medium text-lg">Jumlah Transaksi</h2>
                    <h3><?php echo e($res["jumlahPemesanan"]); ?></h3>
                    <h2 class="font-medium text-lg">Jumlah Produk Terjual</h2>
                    <h3><?php echo e($res["jumlahProdukPemesanan"]); ?></h3>
                    <h2 class="font-medium text-lg">Jumlah Omzet</h2>
                    <h3>Rp. <?php echo e($res["totalPemesanan"]); ?></h3>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minerva/PhpstormProjects/ppl_griees/resources/views/pages/keuangan/kasmasuk.blade.php ENDPATH**/ ?>
<?php $__env->startSection("sidebar"); ?>
    <section id="sidebar" class="bg-slate-200 p-4">
        <h1 class="font-bold mb-3">Tambah Produk Baru</h1>
        <form action="/produk/tambah" enctype="multipart/form-data" method="POST" class="flex flex-col gap-2">
            <?php echo csrf_field(); ?>
            <div>
                <label for="nama">Nama Produk:</label>
                <input type="text" name="nama" id="nama" class="form-input" placeholder="Nama Produk">
            </div>
            <div>
                <label for="varian">Varian:</label>
                <input type="text" name="varian" id="varian" class="form-input" placeholder="Varian">
            </div>
            <div>
                <label for="ukuran">Ukuran:</label>
                <input type="text" name="ukuran" id="ukuran" class="form-input" placeholder="Ukuran">
            </div>
            <div>
                <label for="harga">Harga:</label>
                <input type="number" name="harga" id="harga" class="form-input" placeholder="Harga">
            </div>
            <div>
                <label for="gambar">Gambar:</label>
                <input type="file" name="gambar" id="gambar" class="form-input">
            </div>
            <div>
                <label for="deskripsi">Deskripsi:</label>
                <textarea name="deskripsi" id="deskripsi" cols="30" rows="10" class="form-input"
                          placeholder="Deskripsi"></textarea>
            </div>
            <div class="flex justify-between gap-2">
                <a href="/produk" class="text-center bg-white text-black px-2 py-1 rounded-lg flex-grow">Batal</a>
                <button type="submit" class="text-center bg-slate-500 text-white px-2 py-1 rounded-lg flex-grow">
                    Simpan
                </button>
            </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("pages.produk.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minerva/PhpstormProjects/ppl_griees/resources/views/pages/produk/tambah.blade.php ENDPATH**/ ?>
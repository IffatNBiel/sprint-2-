<div id="detailTransaksi-{{$no+1}}" tabindex="-1"
     class="fixed top-0 left-0 right-0 z-50 hidden p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative w-full max-w-md max-h-full">
        <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
            <div class="p-6 text-center bg-slate-500 rounded-lg">
                <div class="bg-white flex flex-col items-start p-8 gap-3">
                    <p class="font-bold">{{$transaksi->tanggal}}</p>
                    <p>{{$transaksi->user->nama? $transaksi->user->nama : "Pegawai"}}</p>
                    <p>{{$transaksi->user->email}}</p>
                    <table class="w-full">
                        <tr>
                            <th class="border">Keterangan</th>
                            <th class="border">Harga</th>
                            <th class="border">Jumlah</th>
                            <th class="border">Total</th>
                        </tr>
                        @foreach($transaksi->details as $detail)
                            <tr>
                                <td class="border">{{$detail->produk->nama}}</td>
                                <td class="border">{{$detail->produk->harga}}</td>
                                <td class="border">{{$detail->jumlah}}</td>
                                <td class="border">{{$detail->jumlah * $detail->produk->harga}}</td>
                            </tr>
                        @endforeach
                    </table>
                    <div class="flex flex-col w-full items-end">
                        <p>Total: Rp.{{$transaksi->total}}</p>
                        <p>Pajak: Rp.{{(int)($transaksi->total * 0.1)}}</p>
                        <p>Total Akhir: Rp.{{(int)($transaksi->total * 1.1)}}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

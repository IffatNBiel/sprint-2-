@extends("layouts.main")
@section("content")
    <main class="flex-grow">
        <table class="w-full">
            <thead>
            <tr class="bg-gray-100 border-2 border-gray-100">
                <th class="px-8 py-2">No.</th>
                <th class="px-8 py-2">Tanggal</th>
                <th class="px-8 py-2">Jenis Transaksi</th>
                <th class="px-8 py-2">Pembayaran</th>
                <th class="px-8 py-2">Nama Pegawai</th>
                <th class="px-8 py-2">Invoice</th>
            </tr>
            </thead>
            <tbody>
            @foreach($transaksis as $no=>$transaksi)
                <tr>
                    <td class="text-center border-2 border-gray-100">{{$no+1}}</td>
                    <td class="text-center border-2 border-gray-100">{{$transaksi->tanggal}}</td>
                    <td class="text-center border-2 border-gray-100">{{$transaksi->kategori_transaksi}}</td>
                    <td class="text-center border-2 border-gray-100">{{$transaksi->total}}</td>
                    <td class="text-center border-2 border-gray-100">{{$transaksi->user->name}}</td>
                    <td class="text-center border-2 border-gray-100">
                        @include("pages.transaksi.detail")
                        <button type="button" data-modal-target="detailTransaksi-{{$no+1}}" data-modal-toggle="detailTransaksi-{{$no+1}}"
                                class="material-icons">file_open
                        </button>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </main>
@stop

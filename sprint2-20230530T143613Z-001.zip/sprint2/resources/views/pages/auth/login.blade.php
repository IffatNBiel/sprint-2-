@extends("layouts.main")
@section("content")
<main class="flex-grow h-screen flex items-center justify-center">
    <form action="/login" method="POST" class="flex flex-col gap-2">
        @csrf
        <input type="email" name="email" id="email" placeholder="Email">
        <input type="password" name="password" id="password" placeholder="Password">
        <button type="submit" class="bg-slate-200 py-2 rounded-full">Login</button>
    </form>
</main>
@stop

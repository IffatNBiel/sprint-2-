@extends("layouts.main")
@section("content")
    <main class="flex-grow bg-slate-100 p-4">
        <div>
            <canvas id="omzet" class="w-1/4"></canvas>
            <canvas id="jumlah" class="w-1/4"></canvas>
            <canvas id="jumlahproduk" class="w-1/4"></canvas>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            const ctx = document.getElementById('omzet');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: [
                        @foreach($data as $d)
                            "{{$d["tanggal"]}}",
                        @endforeach
                    ],
                    datasets: [{
                        label: 'Total Omzet',
                        data: [
                            @foreach($data as $d)
                                "{{$d["total"]}}",
                            @endforeach
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            const ctxjumlah = document.getElementById('jumlah');
            new Chart(ctxjumlah, {
                type: 'bar',
                data: {
                    labels: [
                        @foreach($data as $d)
                            "{{$d["tanggal"]}}",
                        @endforeach
                    ],
                    datasets: [{
                        label: 'Jumlah Transaksi',
                        data: [
                            @foreach($data as $d)
                                "{{$d["jumlah_transaksi"]}}",
                            @endforeach
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            const ctxjumlahproduk = document.getElementById('jumlahproduk');
            new Chart(ctxjumlahproduk, {
                type: 'bar',
                data: {
                    labels: [
                        @foreach($data as $d)
                            "{{$d["tanggal"]}}",
                        @endforeach
                    ],
                    datasets: [{
                        label: 'Jumlah Produk Transaksi',
                        data: [
                            @foreach($data as $d)
                                "{{$d["jumlah_produk"]}}",
                            @endforeach
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        </script>
    </main>
@stop

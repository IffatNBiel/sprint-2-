@extends("layouts.main")
@section("content")
    <main class="flex-grow h-screen flex items-center justify-center">
        <form method="post" enctype="multipart/form-data" class="p-4 flex flex-col gap-2 items-center">
            @csrf
            <h1>BORANG ISIAN KAS KELUAR</h1>
            <div class="flex gap-2">
                <div class="flex flex-col gap-2">
                    <div>
                        <label for="created_at">Tanggal</label><br>
                        <input class="w-full" type="date" name="created_at" id="created_at">
                    </div>
                    <div>
                        <label for="jenis_pengeluaran">Jenis Pengeluaran</label><br>
                        <select class="w-full" name="jenis_pengeluaran"
                                id="jenis_pengeluaran">
                            <option value="gaji">Gaji</option>
                            <option value="belanja bahan">Belanja Bahan</option>
                            <option value="lainnya">Lainnya</option>
                        </select>
                    </div>
                    <div>
                        <label for="jumlah_pengeluaran">Jumlah Pengeluaran</label><br>
                        <input class="w-full" type="number"
                               name="jumlah_pengeluaran"
                               id="jumlah_pengeluaran">
                    </div>
                    <div>
                        <label for="keterangan">Keterangan</label><br>
                        <textarea class="w-full" name="keterangan" id="keterangan" cols="30"
                                  rows="10"></textarea>
                    </div>
                </div>
                <div>
                    <label for="filebukti">Upload File Bukti</label><br>
                    <input type="file" name="filebukti" id="filebukti">
                </div>
            </div>
            <button type="submit" class="bg-slate-200 w-full py-2 rounded-full">Simpan</button>
        </form>
    </main>
@stop

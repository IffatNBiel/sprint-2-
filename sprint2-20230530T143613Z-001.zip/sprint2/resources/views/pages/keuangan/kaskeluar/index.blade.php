@extends("layouts.main")
@section("content")
    <main class="flex-grow">
        <div class="p-4 flex flex-col items-center">
            <table class="w-full">
                <thead>
                <tr class="bg-gray-100">
                    <th class="px-8 py-2">No.</th>
                    <th class="px-8 py-2">Tanggal</th>
                    <th class="px-8 py-2 w-1/3">Jenis Pengeluaran</th>
                    <th class="px-8 py-2 w-1/3">Jumlah Pengeluaran</th>
                    <th class="px-8 py-2">Keterangan</th>
                    <th class="px-8 py-2">Bukti Pengeluaran</th>
                </tr>
                </thead>
                <tbody>
                @foreach($keluars as $i=>$keluar)
                    <tr>
                        <td>{{$i+1}}</td>
                        <td>{{$keluar->created_at}}</td>
                        <td>{{$keluar->jenis_pengeluaran}}</td>
                        <td>{{$keluar->jumlah_pengeluaran}}</td>
                        <td>{{$keluar->keterangan}}</td>
                        <td><a href="/{{$keluar->bukti}}">Bukti</a></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
            <a href="/keuangan/keluar/tambah" class="mt-4 w-1/3 text-center bg-slate-500 py-2 rounded-xl text-white">Tambah Data</a>
        </div>
    </main>
@stop

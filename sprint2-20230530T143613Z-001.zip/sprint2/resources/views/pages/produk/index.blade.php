@extends("layouts.main")
@section("content")
    <main class="flex-grow">
        <div class="pt-4">
            <div class="flex justify-between items-center h-16">
                <form action="/produk" class="flex items-center bg-slate-200 p-1">
                    <label for="keyword" class="material-icons px-2">search</label>
                    <input type="text" name="keyword" id="keyword" class="bg-slate-200 p-0 border-none">
                </form>
                <h1>Daftar Produk</h1>
                <a href="/produk/tambah" class="bg-slate-200 py-1 px-2">Tambah Produk</a>
            </div>
            <div class="flex flex-wrap justify-start overflow-y-scroll max-h-[calc(100vh-6rem)]">
                @foreach($produks as $produk)
                    <div class="w-[20%] p-1">
                        <button data-modal-target="dataProduk" data-modal-toggle="dataProduk"
                                onclick="getDataProduk('{{$produk->id}}', '{{$produk->nama}}', '{{$produk->gambar}}', '{{$produk->varian->nama}}', '{{$produk->ukuran}}', '{{$produk->harga}}', '{{$produk->deskripsi}}')"
                                class="p-2 border w-full flex flex-col gap-2 items-center">
                            <img src="/{{$produk->gambar}}" class="border h-52 w-full object-cover"
                                 alt="{{$produk->gambar}}">
                            <span class="capitalize font-bold text-xl">{{$produk->nama}}</span>
                            <span>Rp. {{$produk->harga}}</span>
                        </button>
                    </div>
                @endforeach
            </div>
        </div>
    </main>
    @yield("sidebar")
    @include("pages.produk.dataProduk")
    <script src="/js/getDataProduk.js"></script>
@stop

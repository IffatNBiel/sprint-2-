<?php

namespace App\Http\Controllers;

use App\Models\KasKeluar;
use App\Models\Transaksi;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class KeuanganController extends Controller
{
    public function keluar()
    {
        $keluars = KasKeluar::all();
        return view("pages.keuangan.kaskeluar.index", compact("keluars"));
    }

    public function tambahKeluarForm()
    {
        return view("pages.keuangan.kaskeluar.tambah");
    }

    public function tambahKeluar(Request $request)
    {
        $data = $request->validate([
            "created_at" => "required",
            "jenis_pengeluaran" => "required",
            "jumlah_pengeluaran" => "required",
            "keterangan" => "required",
            "filebukti"
        ]);
        $bukti = $request->file("filebukti");
        $data["bukti"] = Storage::put("bukti", $bukti);
        $data["user_id"] = Auth::id();
        $kaskeluar = new KasKeluar($data);
        $kaskeluar->save();
        return redirect("/keuangan/keluar");
    }

    public function bukti($filename)
    {
        if (Storage::has("bukti/" . $filename)) {
            return response()->file(storage_path("app/bukti/$filename"));
        }
        abort(404);
    }

    public function masuk(Request $request)
    {
        $time = $request->input("created_at");
        if ($time) {
            $time = explode("-", $time);
        } else {
            $time = DB::table('transaksis')->latest()->first();
            $time = explode("-", $time->tanggal);
        }
        $data = Transaksi::whereDay("tanggal", $time[2])->whereMonth("tanggal", $time[1])->whereYear("tanggal", $time[0])->with("details")->get();
        $res = [];
        $res["totalPemesanan"] = $data->where("kategori_transaksi", "pemesanan")->sum("total");
        $res["jumlahProdukPemesanan"] = 0;
        foreach ($data->where("kategori_transaksi", "pemesanan") as $p){
            foreach ($p["details"] as $d){
                $res["jumlahProdukPemesanan"] += $d["jumlah"];
            }
        }
        $res["jumlahPemesanan"] = $data->where("kategori_transaksi", "pemesanan")->count();
        $res["totalPembelian"] = $data->where("kategori_transaksi", "pembelian")->sum("total");
        $res["jumlahProdukPembelian"] = 0;
        foreach ($data->where("kategori_transaksi", "pembelian") as $p){
            foreach ($p["details"] as $d){
                $res["jumlahProdukPembelian"] += $d["jumlah"];
            }
        }
        $res["jumlahPembelian"] = $data->where("kategori_transaksi", "pembelian")->count();
        $times = Transaksi::select("tanggal")->groupBy("tanggal")->orderBy("tanggal")->get();
        return view("pages.keuangan.kasmasuk", compact("times", "res"));
    }

    public function laporan(){
        $data = Transaksi::select(DB::raw("DATE_FORMAT(tanggal, '%M-%Y') as tanggal, SUM(total) as total, COUNT(DISTINCT transaksis.id) as jumlah_transaksi, SUM(jumlah)  as jumlah_produk"))->join("detail_transaksis", "transaksis.id", "=", "transaksi_id")->groupBy(DB::raw("DATE_FORMAT(tanggal, '%M-%Y')"))->get();
//        return json_encode($data);
        return view("pages.keuangan.laporan", compact("data"));
    }
}

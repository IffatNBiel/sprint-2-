<?php

namespace App\Http\Controllers;

use App\Models\Jabatan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function loginform()
    {
        return view("pages.auth.login");
    }

    public function login(Request $request)
    {
        $credential = $request->validate([
            "email" => "required|email|exists:users",
            "password" => "required"
        ]);
        if(Auth::attempt($credential)){
            return redirect()->intended();
        }else{
            return back()->withErrors(["password"=>"Password Wrong"]);
        }
    }

    public function registerform(){
        return view("pages.auth.register");
    }
    public function register(Request $request){
        $data = $request->validate([
            "name"=> "required",
            "email"=>"required|unique:users",
            "password"=>"required"
        ]);
        $data["password"] = Hash::make($data["password"]);
        $data["jabatan_id"] = Jabatan::where("jabatan_name", "pegawai")->first()->id;
        $user = new User($data);
        $user->save();
        return redirect()->intended();
    }

    public function logout(){
        Auth::logout();
        return redirect()->intended();
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\DetailTransaksi;
use App\Models\Produk;
use App\Models\Transaksi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class TransaksiController extends Controller
{
    public function index()
    {
        $transaksis = Transaksi::all();
        return view("pages.transaksi.index", compact("transaksis"));
    }

    public function tambahForm()
    {
        $produks = Produk::all();
        return view("pages.transaksi.tambah", compact("produks"));
    }

    public function tambah(Request $request)
    {
        $data = $request->validate([
            "tanggal" => "required",
            "kategori_transaksi" => "required",
            "status_pembayaran" => "required",
            "jumlah_pembayaran" => "required",
            "keterangan" => "required"
        ]);
        $produks = $request->validate([
            "produk" => "required",
            "jumlah" => "required",
        ]);
        DB::beginTransaction();
        try {
            $data["total"] = 0;
            $data["user_id"] = Auth::user()->id;
            for ($i = 0; $i < count($produks["produk"]); $i++) {
                $produk = Produk::find($produks["produk"][$i]);
                $data["total"] += $produk->harga * $produks["jumlah"][$i];
            }
            $transaksi = new Transaksi($data);
            $transaksi->save();
            for ($i = 0; $i < count($produks["produk"]); $i++) {
                $produk = new DetailTransaksi([
                    "produk_id" => $produks["produk"][$i],
                    "jumlah" => $produks["jumlah"][$i],
                    "transaksi_id" => $transaksi->id
                ]);
                $produk->save();
            }
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
        }
        return redirect("/transaksi");
    }
}

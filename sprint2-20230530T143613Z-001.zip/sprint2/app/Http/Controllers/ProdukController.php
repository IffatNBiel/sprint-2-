<?php

namespace App\Http\Controllers;

use App\Models\Produk;
use App\Models\Varian;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use PHPUnit\Exception;

class ProdukController extends Controller
{
    public function index()
    {
        $produks = Produk::all();
        return view("pages.produk.index", compact("produks"));
    }

    public function tambahProdukForm()
    {
        $produks = Produk::all();
        return view("pages.produk.tambah", compact("produks"));
    }

    public function tambahProduk(Request $request)
    {
        $data = $request->validate([
            "nama" => "required",
            "ukuran" => "required",
            "harga" => "required|integer",
            "gambar" => "required",
            "deskripsi" => "required"
        ]);
        $varian = $request->validate([
            "varian" => "required"
        ]);
        $data["stok"] = 0;
        DB::beginTransaction();
        try {
            $varianM = Varian::firstOrCreate(["nama" => $varian["varian"]]);
            $varianM->save();
            $file = $request->file("gambar");
            $data["gambar"] = Storage::put("pic/produk", $file);
            $data["varian_id"] = $varianM->id;
            $produk = new Produk($data);
            $produk->save();
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
        }
        return redirect("/produk");
    }

    public function ubahProdukForm($id)
    {
        $produk = Produk::find($id);
        return view("pages.produk.edit", compact("produk"));
    }

    public function ubahProduk($id, Request $request)
    {
        $data = $request->validate([
            "nama" => "required",
            "ukuran" => "required",
            "harga" => "required|integer",
            "gambar" => "nullable",
            "deskripsi" => "required"
        ]);
        $varian = $request->validate([
            "varian" => "required"
        ]);
        $data["stok"] = 0;
        DB::beginTransaction();
        try {
            $varianM = Varian::firstOrCreate(["nama" => $varian["varian"]]);
            $varianM->save();
            $file = $request->file("gambar");
            if ($file) {
                $data["gambar"] = Storage::put("pic/produk", $file);
            }
            $data["varian_id"] = $varianM->id;
            $produk = Produk::find($id);
            $produk->update($data);
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
        }
        return redirect("/produk");
    }

    public function getDataProduk($id)
    {
        $produk = Produk::find($id);
        return view("pages.produk.index");
    }

    public function getpic($name)
    {
        if (Storage::has("pic/produk/" . $name)) {
            return response()->file(storage_path("app/pic/produk/" . $name));
        }
        abort(404);
    }
}
